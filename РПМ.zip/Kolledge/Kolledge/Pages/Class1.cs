﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kolledge.Pages
{
    class Class1
    {
        public static MainWindow main = new MainWindow();
        public static Teacher teacher = new Teacher();
        public static Student student = new Student();
        public static Dicipline dicipline = new Dicipline();
        public static Group group = new Group();
        public static Journal journal = new Journal();
        public static Role role = new Role();
        public static Schedule schedule = new Schedule();
        public static Specialization specialization = new Specialization();
        public static Specialization_Dicipline specialization_dicipline = new Specialization_Dicipline();
        public static Teacher_Dicipline teacher_dicipline = new Teacher_Dicipline();
        public static User user = new User();


    }
}
