create database [Kolledge]

go

USE [Kolledge]

CREATE TABLE [Role] (

[ID_Role] int PRIMARY KEY,

[Name] varchar (120))

go

CREATE TABLE [User] (

[Login] varchar (50) PRIMARY KEY,

[Password] varchar (120),

[Role] int FOREIGN KEY REFERENCES [Role]([ID_Role]))

go

CREATE TABLE [Student] (

[ID_Student] int PRIMARY KEY,

[FIO] varchar (150),

[Birthday] date,

[������] int,

[�������] varchar (12),

[Login] varchar (50) FOREIGN KEY REFERENCES [User]([Login]))

go

CREATE TABLE [Specialization] (

[ID_Specialization] int PRIMARY KEY,

[Name] varchar (120))



go

CREATE TABLE [Dicipline] (

[ID_Dicipline] int PRIMARY KEY,

[Name] varchar (100))

go

CREATE TABLE [Group] (

[ID_Group] int PRIMARY KEY,

[Course] varchar(2),

[Specialization] int FOREIGN KEY REFERENCES [Specialization] ([ID_Specialization]))



go



go

CREATE TABLE [Specialization_Dicipline] (

[ID_SD] int PRIMARY KEY,

[Dicipline] int FOREIGN KEY REFERENCES [Dicipline]([ID_Dicipline]),

[Specialization] int FOREIGN KEY REFERENCES [Specialization]([ID_Specialization]))

go

CREATE TABLE [Teacher] (

[ID_Teacher] int PRIMARY KEY,

[FIO] varchar (100),

[Birthday] date,

[Login] varchar (50) FOREIGN KEY REFERENCES [User]([Login]))

go

CREATE TABLE [Teacher_Dicipline] (

[ID_TD] int PRIMARY KEY,

[Teacher] int FOREIGN KEY REFERENCES [Teacher] ([ID_Teacher]),

[Dicipline] int FOREIGN KEY REFERENCES [Dicipline] ([ID_Dicipline]))

go

CREATE TABLE [Journal] (

[ID_Jounal] int PRIMARY KEY,

[Date] date,

[Dicipline] int FOREIGN KEY REFERENCES [Teacher_Dicipline]([ID_TD]),

[Group] int FOREIGN KEY REFERENCES [Group] ([ID_Group]),

[Student] int FOREIGN KEY REFERENCES [Student]([ID_Student]),

[Mark] int )

GO

CREATE TABLE [Schedule] (

[Date] date,

[Cabinet] varchar (3),

[Group] int FOREIGN KEY REFERENCES [Group] ([ID_Group]),

[Number_Pair] varchar (1),

[Teacher] int FOREIGN KEY REFERENCES  [Teacher] ([ID_Teacher]),

[Dicipline] int FOREIGN KEY REFERENCES [Dicipline] ([ID_Dicipline]),

PRIMARY KEY ([Date], [Group], [Dicipline] ))
